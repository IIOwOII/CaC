Ta procedura jest uruchamiana, gdy istota osiągnie koniec swojego czasu śmierci.
