这个参数决定了在哪种视角下物品动画会播放。“All Perspectives”将始终允许动画播放，“First Person”仅在进入第一人称视角时播放动画，而“Third/Second Person”仅在未进入第一人称视角时播放动画。
