GeckoLib中json文件的名称。
