class FieldProcedureDisplay extends Blockly.FieldTextInput {}
Blockly.fieldRegistry.register('field_procedure_display', FieldProcedureDisplay);